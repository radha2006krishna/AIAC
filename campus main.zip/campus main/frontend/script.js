const API_BASE = 'http://localhost:3000/api'; // change if backend runs elsewhere

// ----------------------------
// Fetch & Render Requests
// ----------------------------

async function fetchRequests() {
  const status = document.getElementById('filterStatus').value;
  const priority = document.getElementById('filterPriority').value;
  const q = new URLSearchParams();

  if (status) q.set('status', status);
  if (priority) q.set('priority', priority);

  const res = await fetch(`${API_BASE}/requests?${q.toString()}`);
  const data = await res.json();
  renderRequests(data);
}

function renderRequests(requests) {
  const ul = document.getElementById('requestsList');
  ul.innerHTML = '';

  if (!requests.length) {
    ul.innerHTML = '<li class="small">No requests found</li>';
    return;
  }

  requests.forEach(r => {
    const li = document.createElement('li');
    li.className = 'request';
    li.innerHTML = `
      <div>
        <strong>${escapeHtml(r.title)}</strong>
        <div class="meta">${escapeHtml(r.location || '—')} • ${new Date(r.created_at).toLocaleString()}</div>
        <div class="small">${escapeHtml(r.description || '')}</div>
      </div>
      <div class="actions">
        <div class="meta">
          Priority: ${escapeHtml(r.priority)} <br/>
          Status: <span class="${statusClass(r.status)}">${escapeHtml(r.status)}</span>
        </div>
        <div>
          <button onclick="updateStatus(${r.id}, 'In Progress')">Set In Progress</button>
          <button onclick="updateStatus(${r.id}, 'Closed')">Close</button>
          <button onclick="deleteRequest(${r.id})">Delete</button>
        </div>
      </div>
    `;
    ul.appendChild(li);
  });
}

// ----------------------------
// Helpers
// ----------------------------

function statusClass(status) {
  if (!status) return '';
  if (status.toLowerCase().includes('open')) return 'status-open';
  if (status.toLowerCase().includes('closed')) return 'status-closed';
  if (status.toLowerCase().includes('progress')) return 'status-inprogress';
  return '';
}

function escapeHtml(s) {
  if (!s) return '';
  return s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

// ----------------------------
// Create / Update / Delete Requests
// ----------------------------

async function createRequest(e) {
  e.preventDefault();

  const title = document.getElementById('title').value.trim();
  const location = document.getElementById('location').value.trim();
  const priority = document.getElementById('priority').value;
  const description = document.getElementById('description').value.trim();

  if (!title) return alert('Title required');

  const res = await fetch(`${API_BASE}/requests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, location, priority, description })
  });

  if (!res.ok) return alert('Error creating request');

  document.getElementById('requestForm').reset();
  fetchRequests();
}

async function updateStatus(id, status) {
  await fetch(`${API_BASE}/requests/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status })
  });
  fetchRequests();
}

async function deleteRequest(id) {
  if (!confirm('Delete this request?')) return;

  await fetch(`${API_BASE}/requests/${id}`, { method: 'DELETE' });
  fetchRequests();
}

// ----------------------------
// DOM Ready
// ----------------------------

window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('requestForm').addEventListener('submit', createRequest);
  document.getElementById('refresh').addEventListener('click', fetchRequests);
  document.getElementById('filterStatus').addEventListener('change', fetchRequests);
  document.getElementById('filterPriority').addEventListener('change', fetchRequests);

  fetchRequests(); // Load on page start
});
