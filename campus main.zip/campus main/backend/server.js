// server.js
const express = require('express');
const cors = require('cors');
const { db, init } = require('./db');

init();

const app = express();
app.use(cors());
app.use(express.json());

// Create a request
app.post('/api/requests', (req, res) => {
  const { title, description, location, priority } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });

  const sql = `INSERT INTO requests (title, description, location, priority) VALUES (?, ?, ?, ?)`;
  db.run(sql, [title, description || '', location || '', priority || 'Normal'], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    const insertedId = this.lastID;

    db.get('SELECT * FROM requests WHERE id = ?', [insertedId], (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json(row);
    });
  });
});

// Get all requests
app.get('/api/requests', (req, res) => {
  const { status, priority } = req.query;
  let sql = 'SELECT * FROM requests';
  const params = [];
  const conditions = [];

  if (status) { conditions.push('status = ?'); params.push(status); }
  if (priority) { conditions.push('priority = ?'); params.push(priority); }

  if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
  sql += ' ORDER BY created_at DESC';

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Update a request
app.put('/api/requests/:id', (req, res) => {
  const { id } = req.params;
  const fields = ['title', 'description', 'location', 'priority', 'status'];
  const updates = [];
  const params = [];

  fields.forEach(f => {
    if (req.body[f] !== undefined) {
      updates.push(`${f} = ?`);
      params.push(req.body[f]);
    }
  });

  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  params.push(id);

  const sql = `UPDATE requests SET ${updates.join(', ')} WHERE id = ?`;
  db.run(sql, params, function (err) {
    if (err) return res.status(500).json({ error: err.message });

    db.get('SELECT * FROM requests WHERE id = ?', [id], (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!row) return res.status(404).json({ error: 'Not found' });
      res.json(row);
    });
  });
});

// Delete request
app.delete('/api/requests/:id', (req, res) => {
  const { id } = req.params;

  db.run('DELETE FROM requests WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });

    res.json({ success: true });
  });
});

// Healthcheck
app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
